<?php 
require 'config.php';
  $tampil = query ("SELECT * FROM post");

 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>Indri Dwi Damayanti</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="cover.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="site-wrapper">

      <div class="site-wrapper-inner">

        <div class="cover-container">

          <div class="masthead clearfix">
            <div class="inner">
              <h3 class="masthead-brand">Cover</h3>
              <ul class="nav masthead-nav">
                <li><a href="index.php">Home</a></li>
                <li class="active"><a href="mahasiwa.php">Mahasiswa</a></li>
                <li><a href="formlogin.php">Login</a></li>
                <li><a href="formregister.php">Registrasi</a></li>
              </ul>
            </div>
          </div>

           <div id="isi">
  
          <center>
          <br>
          <h2>PROFILE MAHASISWA</h2>
          <br><br>
          <table border="2" cellpadding="40" cellspacing="10">
          <tr>
          <th>No</th>
          <th>Nama</th>
          <th>NIM</th>
          <th>TTL</th>
          <th>Waktu Update</th>
          </tr> 

        <?php $i=1; ?>
        <?php foreach ($tampil as $x ) : //foreach itu pengulangan pada array  ?> 
        <tr>
        <td><?= $i; ?></td>
        <td><?= $x["Nama"] ?></td>
        <td><?= $x["NIM"] ?></td>
        <td><?= $x["TTL"];  ?></td>
        <td><?= $x["waktu"];  ?></td>
   
        </tr>
        <?php $i++; ?>
        <?php endforeach; ?>
        </table>
      </center>

    </div>

          <div class="mastfoot">
            <div class="inner">
              <p>Cover template for <a href="http://getbootstrap.com">Bootstrap</a>, by <a href="https://twitter.com/mdo">@mdo</a>.</p>
            </div>
          </div>

        </div>

      </div>

    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="jquery.min.js"></script>
    <script src="bootstrap.min.js"></script>
    <script src="docs.min.js"></script>
  </body>
</html>
